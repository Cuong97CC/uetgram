$(document).ready(function () {

  'use strict';
  // ------------------------------------------------------- //
  // Search Box
  // ------------------------------------------------------ //
  $('#search').on('click', function (e) {
    e.preventDefault();
    $('.search-box').fadeIn();
    $('#searchContent').focus();
  });
  $('.dismiss').on('click', function () {
    $('.search-box').fadeOut();
  });
  // ------------------------------------------------------- //
  // Sidebar Functionality
  // ------------------------------------------------------ //
  $('#toggle-btn').on('click', function (e) {
    e.preventDefault();
    $(this).toggleClass('active');

    $('.side-navbar').toggleClass('shrinked');
    $('.content-inner').toggleClass('active');

    if ($(window).outerWidth() > 1183) {
      if ($('#toggle-btn').hasClass('active')) {
        $('.navbar-header .brand-small').hide();
        $('.navbar-header .brand-big').show();
      } else {
        $('.navbar-header .brand-small').show();
        $('.navbar-header .brand-big').hide();
      }
    }

    if ($(window).outerWidth() < 1183) {
      $('.navbar-header .brand-small').show();
    }
  });

});

$("div.alert").delay(3000).slideUp();

$('#searchForm').on('keyup keypress', function (e) {
  var keyCode = e.keyCode || e.which;
  if (keyCode === 13 && !$("#searchContent").val()) {
    e.preventDefault();
    return false;
  }
});

$("#searchContent").change(function () {
  if ($("#searchContent").val()) {
    $('#searchForm').attr('action', '/search/' + $("#searchContent").val());
  } else {
    $('#searchForm').attr('action', '#');
  }
});

$("#img-form").change(function () {
  $("#image").empty();
  var typeValid = true;
  var sizeValid = true;
  var typeError = '<p style="color: red"> Định dạng không được hỗ trợ! </p>';
  var sizeError = '<p style="color: red"> Dung lượng quá lớn để tải lên! </p>';
  for (var i = 0; i < $('#img-form')[0].files.length; i++) {
    if (this.files && this.files[i]) {
      var img = $('#img-form')[0].files[i];
      var fsize = img.size;
      if (!img.name.match(/.(jpg|png|jpeg|jpe)$/i)) {
        typeValid = false;
      }
      if (fsize > 3000000) {
        sizeValid = false;
      }
    }
  }
  if (typeValid && sizeValid) {
    document.getElementById('img-form').style.border = "1px solid #09F";
    document.getElementById('add-img-bt').disabled = false;
    readURL(this);
  } else {
    if (!typeValid) {
      $("#image").append(typeError);
    }
    if (!sizeValid) {
      $("#image").append(sizeError);
    }
    document.getElementById('img-form').style.border = "3px solid #F00";
    document.getElementById('add-img-bt').disabled = true;
  }
});

function readURL(input) {
  if (input.files) {
    var l = $('#img-form')[0].files.length;
    if (l <= 5) {
      var width = 100 / l;
      var reader = new Array();
      for (var i = 0; i < l; i++) {
        reader[i] = new FileReader();
        reader[i].onload = function (e) {
          var html = '<img src="' + e.target.result + '" width="' + width + '%" style="padding:2px;"/>'
          $("#image").append(html);
        }
        reader[i].readAsDataURL(input.files[i]);
      }
    } else if (l > 5) {
      var width = 20;
      var reader = new Array();
      for (var i = 0; i < l; i++) {
        reader[i] = new FileReader();
        reader[i].onload = function (e) {
          var html = '<img src="' + e.target.result + '" width="' + width + '%" style="padding:2px;"/>'
          $("#image").append(html);
        }
        reader[i].readAsDataURL(input.files[i]);
      }
    }
  }
}

$(document).ready(function () {
  var last = localStorage.getItem("id");
  if (last != null) {
    //remove default collapse settings
    $("#searchResult .collapse").removeClass('show');
    //show the last visible group
    $("#" + last).collapse("show");
  }
});

$('#searchResult').on('shown.bs.collapse', function () {
  var active = $("#searchResult .show").attr('id');
  localStorage.setItem('id', active);
});

$('#searchResult').on('hidden.bs.collapse', function () {
  localStorage.removeItem('id');
});

function clickImg(index) {
  $("header.up").slideUp();
  $("section.up").slideUp();
  $("#image-detail").fadeIn();
  $('#image-detail').find('.carousel-item:nth-child(' + index + ')').addClass('active');
}

function hide() {
  $("#image-detail .carousel-item.active").removeClass('active');
  $("#image-detail").fadeOut();
  $("header.up").slideDown();
  $("section.up").slideDown();
}

$(document).ready(function () {
  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  })
});

function comment(id, name, lv) {
  var content = $("#form-cmt" + id).find("textarea[name='content']").val();
  if (content.trim() != "") {
    var _token = $('meta[name="csrf-token"]').attr('content');
    $.ajax({
      url: "/images/comments/" + id + "/addcomment",
      type: "POST",
      cache: false,
      data: {
        "_token": _token,
        "content": content,
        "idImg": id
      },
      success: function (data) {
        if (data) {
          if (lv == 0) {
            var html = `<div class="comment" id="comment` + data + `">
                            <p class="inline"><strong><a href="/images/user/` + name + `">` + name + `</a></strong> : ` + content + `</p></br>
                            <button onClick="deleteCmt(` + data + `)" class="btn btn-sm btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></button>
                        </div>`;
          } else {
            var html = `<div class="comment" id="comment` + data + `">
                            <p class="inline"><strong><a href="/images/user/` + name + `">` + name + `</a></strong> : ` + content + `</p></br>
                            <button onClick="deleteCmt(` + data + `)" class="btn btn-sm btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></button>
                            <button onClick="makeDescription(` + data + `,` + id + `)" class="btn btn-sm btn-info"><i class="fa fa-check-square-o" aria-hidden="true"></i></button>
                            </div>`;
          }
          $("#comment-area" + id).append(html);
          $("#form-cmt" + id).find("textarea[name='content']").val('');
        }
      }
    });
  }
}

function makeDescription(idCmt, idImg) {
  var _token = $('meta[name="csrf-token"]').attr('content');
  $.ajax({
    url: "/images/" + idImg + "/description",
    type: "POST",
    cache: false,
    data: {
      "_token": _token,
      "idImg": idImg,
      "idCmt": idCmt
    },
    success: function (data) {
      if (data) {
        $("#img-content" + idImg).html(data);
      }
    }
  });
}

function editTitle(idImg) {
  var old = $("#title" + idImg).html();
  var title = $("#img-title" + idImg).html();
  if(title) {
    title = title.trim();
  }
  $("#title" + idImg).empty();
  var html = `<input type="text" class="form-control" placeholder="Tiêu đề..." id="edit-title` + idImg + `">`;
  $("#title" + idImg).append(html);
  $("#edit-title" + idImg).val(title);
  $("#edit-title" + idImg).focus();
  $("#edit-title" + idImg).on('keyup', function (e) {
    var title = $("#edit-title" + idImg).val();
    if (e.keyCode == 13 && title.trim() != '') {
      var _token = $('meta[name="csrf-token"]').attr('content');
      $.ajax({
        url: "/images/" + idImg + "/edit",
        type: "POST",
        cache: false,
        data: {
          "_token": _token,
          "idImg": idImg,
          "title": title
        },
        success: function (data) {
          if (data) {
            var json = JSON.parse(data);
            $("#title" + idImg).empty();
            var newTitle = `<h1 id="img-title` + idImg + `" class="inline">` + json['title'] + `     </h1>
            <h1 class="inline"><a href="javascript:void(0)" onClick="editTitle(` + idImg + `)"><i class="fa fa-pencil" aria-hidden="true"></i></a></h1>`;
            $("#title" + idImg).append(newTitle);
          }
        }
      });
    }
  });
  $("#edit-title" + idImg).focusout(function () {
    $("#title" + idImg).empty();
    $("#title" + idImg).append(old);
  });
}

function editDescription(idImg) {
  var old = $("#content" + idImg).html();
  var content = $("#img-content" + idImg).html();
  if(content) {
    content = content.trim();
  }
  $("#content" + idImg).empty();
  var html = `<textarea class="form-control" rows="3" placeholder="Mô tả..." id="edit-content` + idImg + `"></textarea>`;
  $("#content" + idImg).append(html);
  $("#edit-content" + idImg).val(content);
  $("#edit-content" + idImg).focus();
  $("#edit-content" + idImg).on('keyup', function (e) {
    var content = $("#edit-content" + idImg).val();
    if (e.keyCode == 13 && content.trim() != '') {
      var _token = $('meta[name="csrf-token"]').attr('content');
      $.ajax({
        url: "/images/" + idImg + "/edit",
        type: "POST",
        cache: false,
        data: {
          "_token": _token,
          "idImg": idImg,
          "content": content
        },
        success: function (data) {
          if (data) {
            var json = JSON.parse(data);
            $("#content" + idImg).empty();
            var newContent = `<p id="img-content` + idImg + `" class="inline">` + json['content'] + `     </p>  
              <a href="javascript:void(0)" onClick="editDescription(` + idImg + `)"><i class="fa fa-pencil" aria-hidden="true"></i></a>`;
            $("#content" + idImg).append(newContent);
          }
        }
      });
    }
  });
  $("#edit-content" + idImg).focusout(function () {
    $("#content" + idImg).empty();
    $("#content" + idImg).append(old);
  });
}

function deleteCmt(id) {
  var _token = $('meta[name="csrf-token"]').attr('content');
  $.ajax({
    url: "/images/comments/delete/" + id,
    type: "POST",
    cache: false,
    data: {
      "_token": _token,
      "id": id
    },
    success: function (data) {
      if (data) {
        $("#comment" + data).remove();
      }
    }
  });
}

function addTag(id) {
  var html = `<div id="tag-input` + id + `">
                <div class="input-group input-group-sm" style="width:100%">
                <span class="input-group-addon input-group-addon-sm">#</span>
                <input id="input` + id + `" type="text" class="form-control input-sm" placeholder="Nhãn...">
                </div>
              </div>`;
  $("#add-tag-area" + id).empty();
  $("#add-tag-area" + id).append(html);
  $("#input" + id).focus();
  $("#input" + id).on('keyup', function (e) {
    var content = $("#input" + id).val();
    if (e.keyCode == 13 && content.trim() != '') {
      var _token = $('meta[name="csrf-token"]').attr('content');
      $.ajax({
        url: "/images/tags/" + id + "/addtag",
        type: "POST",
        cache: false,
        data: {
          "_token": _token,
          "idImg": id,
          "content": content
        },
        success: function (data) {
          if (data == "Existed") {
            $("#tagExistModal").modal("show");
          } else {
            var json = JSON.parse(data);
            var tag = `<div id="tag` + json['id'] + `" class="inline tag">
                        <a href="/images/tags/` + json['content'] + `" class="tag-content">#` + json['content'] + `</a>
                        <a href="javascript:void(0)" onClick="deleteTag(` + id + `,` + json['id'] + `)" class="tag-del"><i class="fa fa-times" aria-hidden="true"></i></a>
                        </div>`;
            $("#tag-area" + id).append(tag);
            $("#add-tag-area" + id).empty();
          }
        }
      });
    }
  });
  $("#input" + id).focusout(function () {
    $("#add-tag-area" + id).empty();
  });
}

function deleteTag(idImg, idTag) {
  var _token = $('meta[name="csrf-token"]').attr('content');
  $.ajax({
    url: "/images/tags/" + idImg + "/delete/" + idTag,
    type: "POST",
    cache: false,
    data: {
      "_token": _token,
      "idImg": idImg,
      "idTag": idTag
    },
    success: function (data) {
      if (data == "OK") {
        $("#tag" + idTag).remove();
      }
    }
  });
}

function downloadSingle(location) {
  $("#single-hidden-link").attr("href", location);
  document.getElementById("single-hidden-link").click();
}