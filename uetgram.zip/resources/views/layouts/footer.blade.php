<footer class="main-footer">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6">
        <p>Copyright &copy; 2017</p>
      </div>
      <div class="col-sm-6 text-right">
        <p>Nhóm 3</p>
      </div>
    </div>
  </div>
</footer>